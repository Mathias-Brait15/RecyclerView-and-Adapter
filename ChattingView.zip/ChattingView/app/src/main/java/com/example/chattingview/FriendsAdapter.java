package com.example.chattingview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FriendsAdapter extends RecyclerView.Adapter<FriendsAdapter.FriendViewHolder> {
    private ArrayList<Friends> friends;

    public static class FriendViewHolder extends RecyclerView.ViewHolder{
        public ImageView imageView;
        public TextView name ;
        public TextView text;

        public FriendViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            name = itemView.findViewById(R.id.textView);
            text = itemView.findViewById(R.id.textView2);


        }
    }

    public FriendsAdapter(ArrayList<Friends> friendsArrayList){

        this.friends = friendsArrayList;

    }
    @NonNull
    @Override
    public FriendViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list , parent , false);
        FriendViewHolder friendViewHolder = new FriendViewHolder(v);
        return  friendViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull FriendViewHolder holder, int position) {
       Friends current = friends.get(position);
       holder.name.setText(current.getName());
       holder.text.setText(current.getText());
    }

    @Override
    public int getItemCount() {
        return friends.size();
    }
}
