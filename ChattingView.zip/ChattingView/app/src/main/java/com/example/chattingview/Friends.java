package com.example.chattingview;

public class Friends {
    private int Image ;
    private String Name ;
    private String Text ;


    public Friends(int image, String name, String text) {
        Image = image;
        Name = name;
        Text = text;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getText() {
        return Text;
    }

    public void setText(String text) {
        Text = text;
    }
}

