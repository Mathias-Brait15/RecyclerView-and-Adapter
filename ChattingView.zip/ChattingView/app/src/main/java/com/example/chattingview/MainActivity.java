package com.example.chattingview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView ;
    private RecyclerView.Adapter mAdapter ;
    private RecyclerView.LayoutManager mLayoutManager;
    private  ArrayList<Friends> itemfriends; 
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       ArrayList<Friends> itemfriends = new ArrayList<>();
       itemfriends.add(new Friends(R.drawable.ic_launcher_foreground,"Mathias" , "Okay, see you"));
       itemfriends.add(new Friends(R.drawable.ic_launcher_foreground,"Rama" , "Im sorry, i cant go. Thank you for invite me"));
       itemfriends.add(new Friends(R.drawable.ic_launcher_foreground, "Thomas" , "Sure, lets go!"));

        mRecyclerView = findViewById(R.id.recycler_view);

        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);

        mAdapter = new FriendsAdapter(itemfriends);

        mRecyclerView.setLayoutManager(mLayoutManager);

        mRecyclerView.setAdapter(mAdapter);




    }
}
